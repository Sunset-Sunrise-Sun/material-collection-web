# 广州地图宿主维护接口（已接入）

原V3地图槽v1保持不变；当前provider已接入冻结v1.0.0组件。接入依据是交付原文`map-module/集成说明.md`，本轮验收见`MAP_INTEGRATION_ACCEPTANCE.md`。

## 文件与位置

仅第4章4.1、4.1.1之前挂载完整地图；第2章保留原区位图。`dist/map-provider.js`和CSS负责宿主适配，`dist/assets/maps/`存放原样交付的JS、JSON和GeoJSON。不得直接修改冻结资源或研究数据来做视觉修补；若必须修组件，先记录复现和修改理由。

## 槽接口

```js
window.ResearchMapSlot.register(async ({container, context}) => {
  // context: section, city, scope, baseline
  // V3.0.1新增可选districtOrder：原v2床位图的区名顺序。
  // 在container内挂载；可以返回清理函数。
  return () => {};
});
```

槽捕获provider异步异常，降级不影响报告。当前provider的脚本/数据读取超时12秒，不无限重试，也不加入报告初始化等待链。

## 可见性与事件

首次显示第4章后mount，避免隐藏元素宽为0。离开视图保留DOM与组件实例；重新进入触发resize。`document`发送`research:viewchange`，detail.view是章节id。不要因为视图切换重建报告或重置地图状态。

组件API严格遵守交付文档：data/geometry属性注入；setMetric、select(adcode,{source:'api'})、highlight、destroy等。宿主只在`gzmap:select`的source=map方向更新条形；点击条形先同步自身再调用API。reset单独同步。metricchange以同一对象重绘当前指标条形与来源；hover仅改变高亮，不派发选区。

## 数据与排序

联动条形与地图同源，不在宿主重算。使用原v2床位图区序，切换指标不新建排名，focusRule=null。原V3床位图在4.1.1证据层保留，原visual-data.json不变。新地图显示的小数位与旧图不同，页面注明；不以新口径重算原报告相关统计。

## 开发验收

`npm run dev`，访问`/#s-4-1`。`/qa-map-host.html`由开发服务器提供390/1280px iframe及事件计数；文件在scripts下，不进入dist部署。`npm run check`检查冻结文件哈希、范围、失败隔离与88项已保存浏览器读数；UI实测记录与组件自测须区分。

主题仅通过公开CSS变量修改，CSS限于宿主范围，不穿透Shadow DOM改内部结构。GeoJSON在开发服务器为application/geo+json；正式托管MIME/CSP与登录资源访问必须发布后核验，不能预先宣称通过。
