# V3地图集成文件清单

项目：/workspace/sites/guangzhou-ai-care；原Sites项目ID保持不变。

| 路径 | 修改原因 |
|---|---|
| dist/map-provider.js | 替换空provider：懒加载冻结组件/数据、超时降级、固定区序的联动条形、双向选区与重置、清理 |
| dist/map-provider.css | 仅宿主范围的绿色主题变量、联动条形、质量提示与手机布局 |
| dist/overview.js | 4.1启用地图入口和边界提示；原V3床位图转为可展开证据；将原区序传入provider |
| dist/index.html | 阅读说明更新为“地图已接入本次预览”，保留V3品牌与7视图 |
| dist/assets/maps/gz-district-map.js | 原样复制冻结v1.0.0脚本，未重做地图 |
| dist/assets/maps/district_metrics.json | 原样复制交付指标；未改研究数据 |
| dist/assets/maps/gz_districts_11.geojson | 原样复制边界；许可/坐标待核状态不变 |
| scripts/serve.mjs | 补GeoJSON MIME；仅开发服务提供验收iframe页面，不打包到线上静态资源 |
| scripts/qa-map-host.html | 390/1280px宿主测试视口与事件计数，非正式研究展示页 |
| scripts/verify_map_integration.py | 冻结资产及原V3哈希、8指标与88项浏览器读数核对 |
| package.json | 0.3.1，纳入地图检查，无新依赖 |
| docs/MAP_ASSET_MANIFEST.json | 记录vendor与原V3数据/图片SHA-256基线 |
| docs/MAP_HOST_RESULTS.json | 保存本轮宿主UI读数、事件/历史与测试边界 |
| docs/MAP_INTEGRATION_ACCEPTANCE.md | 阶段1证据、集成验收、限制和未发布状态 |
| docs/MAP_INTEGRATION_CHANGES.md | 本文件 |
| docs/MAP_INTEGRATION.md | 更新已接入后的接口/维护说明 |
| docs/map-module/*.md | 原样保留模块交付文档，区分原自测与本轮宿主测试 |
| docs/map-module/component-test-results.json | 原执行方48项测试机器记录 |
| docs/screenshots/map-*.jpg | 本轮宿主桌面、390px、条形联动截图 |
| docs/STATUS.md、docs/HANDOFF_DEEPSEEK.md、README.md | 更新运行、交接与预览状态 |

未修改：dist/content.json、visual-data.json、4张原图、map-slot.js、章节路由、原统计结论、参考文献。未修改辅助材料仓库中的数据。
