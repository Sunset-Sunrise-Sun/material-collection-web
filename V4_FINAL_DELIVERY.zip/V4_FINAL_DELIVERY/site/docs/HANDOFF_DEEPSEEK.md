# DeepSeek继续实施提示词（V3地图集成预览）

你接手的是已有原Sites项目的集成预览，不是空项目。不要重建整站、换框架或重做地图。先读README、docs/STATUS.md、MAP_INTEGRATION_ACCEPTANCE.md、MAP_INTEGRATION_CHANGES.md、MAP_INTEGRATION.md与map-module/集成说明.md。

工程原路径/workspace/sites/guangzhou-ai-care；ZIP解压后使用同名目录。Node18+运行npm run dev，访问http://localhost:3000/#s-4-1；无需npm install。npm run check需Python3，检查范围见README。/qa-map-host.html仅开发服务器提供390/1280px宿主验收iframe与事件计数，非正式部署页。

原Sites项目ID：appgprj_6ae1dfadd1d881919108d471a52f69cf。原线上：https://guangzhou-ai-care-research-v2.roundtrail24.chatgpt.site/。当前线上仍为未接入地图的V3。原生Sites接口确认owner并打开已发布基线b2fe941537c425ff93ac4272b4649e1095046353，浏览器本身未登录。源码合法取得，没有抓取或反向重建。**本轮已完成源码集成和本地验收，尚未发布**；不能把源码保存、预览或本地副本写成已更新线上。用户明确要求回归测试和发布授权后再发布，请沿用该边界；无授权不要deploy。

已实现：4.1独立地图槽挂载交付的gz-district-map v1.0.0；assets/maps三文件均与上传包字节一致。provider仅适配加载、12秒超时、固定原区序条形、select/metricchange/hover/reset与清理。地图与条形来自同一对象，source过滤避免回环。第2章原区位图保留。原V3床位图转为4.1.1可展开证据记录，没有删图或改原数值。CSS通过公开变量适配深绿UI，没有穿透Shadow DOM改冻结组件。

V3仍是7独立视图，DOM只挂载一次，隐藏其余。view-router.js负责锚点、history.scrollRestoration=manual、每个条目的scrollY。首次第4章可见后mount，重入resize，不重建地图实例。保持content.json、visual-data.json、4原图、map-slot和路由不变。

本轮实测：桌面1363×936无溢出；390px iframe内容375宽、地图/条形331宽无溢出。8指标×11区88值对照交付JSON一致；地图点黄埔与条形点越秀双向联动。独立事件计数为地图键盘0→1，条形1→2，reset2→3并两侧清空。桌面169→第2章0→back169→forward0；移动380→第2章0→back380，指标保留。原区域图放大1265×958；浏览器89段13766字符逐段等于原content。正常页面未见app error/warn，chrome-extension元数据报错已单独排除。原组件48/48是交付方结果，没有冒充本轮重跑。机读记录MAP_HOST_RESULTS.json、哈希MAP_ASSET_MANIFEST.json、宿主截图docs/screenshots/可复核。

下一步：取得用户对同一私有站点的明确发布确认后，使用原Sites工作流保存/部署，保持项目ID和受众。不能绕过登录/Cloudflare/CSP。正式站点登录后资源与CSP、宿主UI、章节历史仍须验收；可视化编辑器UI、真机触摸、Safari/Firefox、读屏尚未验证。本地390 iframe不是设备仿真。截图clip接口超时，现有截图为真实原始视口（含390验收框）；不要用交付模块自身截图冒充主站。

研究边界必须保留：备案床位2026-09/户籍60+2025跨年；备案≠可用，设施计数≠能力；2条机构区划冲突、2组饭堂重复、2023-11医疗名录未修；边界许可/CRS/审图号待核；focusRule=null，未有正式重点区规则，不新增排名；只到区级，不作需求缺口/街镇匹配/因果或AI效果判断。原报告4.4称五主题但只有四段标题正文，第五继续待核。S1—S7、L1—L3、A—D、路线时间和19文献不变。地图数据不自动成为重算原稿统计的授权。

用户原报告v2 SHA-256为6c0ef1facd8e52da8af7f2081c686e4b27bbaaf78b18a9846b0924c4da7a43f6；ZIP不含原DOCX，没有时不得假装读过。参考仓库只辅助，未修改其数据。每阶段保存状态，不猜剩余额度。遇阻记录实际复现与未测项，避免循环尝试失败路径。
