# 筑工杯广州AI养老研究成果网页

《从场景清单到审慎试点：广州AI养老研究》的V4候选网页：在原V4源码基础上，将边界许可/审图未闭合的行政区地图替换为**非地理的11区区级比较面板**，保留11区/8指标/88值/条图联动/区级详情/章节结构。保持米白背景、深绿强调、五章与参考文献。静态HTML/CSS/JS，零运行时依赖，无须npm install。

**当前状态：安全候选版已本地验收，尚未保存/发布。原线上V3未更新。** 原Sites项目ID与受众保持不变；安全面板未再次保存为Sites版本。

## 本地启动

需要Node.js 18+。进入项目或解压后的同名目录：

```bash
npm run dev
```

打开`http://localhost:3000/#s-4-1`查看地图；首页为`http://localhost:3000/`。换端口：

```bash
npm run dev -- --port 8080
```

也可仅运行正式静态页：

```bash
python3 -m http.server 3000 --directory dist
```

必须经HTTP(S)访问，不能双击HTML。组件和两份数据均在`dist/assets/maps/`，不使用本地Windows路径或外部CDN。

## 验收

基础检查需Python3，不需要python-docx：

```bash
npm run check
```

检查语法、原稿范围、原图表算术、引文映射、地图失败隔离、冻结文件SHA-256、原V3内容不变和已保存的88项浏览器读数。该命令不会自动启动浏览器，也不应当被称为重新执行全部UI测试。

使用`npm run dev`时可打开`http://localhost:3000/qa-map-host.html`，测试390/1280px宿主视口与事件计数。该页面由开发服务单独提供，**不在dist中，不会部署到正式静态站点**。390px iframe含浏览器滚动条，内容宽375px；不是手机真机或触摸设备仿真。

本轮实际宿主验收、阶段1能力证据与限制见`docs/MAP_INTEGRATION_ACCEPTANCE.md`；逐文件改动见`docs/MAP_INTEGRATION_CHANGES.md`；机器读数在`docs/MAP_HOST_RESULTS.json`；截图在`docs/screenshots/`。

交付模块自身48/48通过是独立执行方的测试，报告原件保存在`docs/map-module/`；本轮没有冒充重跑组件全部单测。

## 结构与维护

| 文件 | 作用 |
|---|---|
| dist/index.html、styles.css、views.css | 首页、布局、V3章节层级和导航 |
| dist/view-router.js | 总览、五章、参考文献7视图，旧锚点、历史与阅读位置 |
| dist/app.js | v2正文、审计筛选/展开、图片放大、引用和路线图 |
| dist/introduction.js | 第1章背景与文献综合视图，保留全文展开 |
| dist/overview.js、overview.css | 第4章概览、年度图、同源场景卡片、田野与治理入口 |
| dist/content.json | 原报告正文、审计表、41子标题、19参考文献，未修改 |
| dist/visual-data.json | v2派生图表口径与数值，未修改 |
| dist/assets/image1.png—image4.png | 原报告4张图片，未修改 |
| dist/map-slot.js | 独立地图provider接口、异步错误降级，未修改 |
| dist/map-provider.js/CSS | 地图懒加载、主题、同源联动条形、固定原区序、清理 |
| dist/assets/maps/ | 冻结的地图JS/JSON/GeoJSON，均未改动 |
| docs/MAP_ASSET_MANIFEST.json | vendor及原V3数据/原图的哈希基线 |
| scripts/verify_map_integration.py | 文件完整性和宿主读数核对 |
| .openai/hosting.json | 原Sites项目身份及dist静态目录，继续保留 |

第4章4.1挂载非地理的11区比较面板，只挂载一次。第2章保留原区位图。面板与条形读取同一份district_metrics对象，不复制状态数据、不重算指标；8指标切换不新增排名。原V3床位图保存在4.1.1的证据展开层。面板故障时完整报告和原图表仍可阅读。

可视化派生口径见`docs/VISUAL_SOURCES.md`；v2来源见`docs/SOURCE.md`。新增研究材料不能直接覆盖v2正文或原统计结论。审计卡片、审计表及S1/S5对照仍共用原审计行。

## 内容边界与待办

- 保留89段原文13766字符、五章原序、S1—S7、L1—L3、A—D及三阶段路线。原稿4.4只有四个实际主题，第五主题继续待核。
- 地图的2026备案床位与2025户籍60+人口跨年；备案不等于可用床位。点位数不是服务能力，2条机构区划冲突、2组饭堂同址重复及较旧医疗名录均未修正。
- 本候选版不使用行政区边界，避免在边界许可/审图未闭合时再分发；不标注未有正式规则支持的重点关注区。不作街镇供需匹配、因果或AI效果判断。
- 年度图只比较2024/2025端点，人次不等于人数/AI服务量。原相关结果未重算；地图数据不自动成为替代原统计的依据。
- 仍待正式站点发布后的登录/CSP/资源回归、真机触摸、Safari/Firefox与读屏验收，以及文献全文与统计原件深度复核。

参考资料仓库只作辅助：<https://github.com/Sunset-Sunrise-Sun/material-collection>。未改原报告或该仓库数据。交接说明见`docs/HANDOFF_DEEPSEEK.md`。
