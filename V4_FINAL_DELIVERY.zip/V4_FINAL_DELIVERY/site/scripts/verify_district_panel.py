"""Final candidate contract checks for the safe, non-geographic district comparison panel."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
dist = root / 'dist'

# 1) no administrative boundary geometry or map component is shipped
for forbidden in [dist / 'assets' / 'maps', dist / 'map-provider.js', dist / 'map-provider.css']:
    assert not forbidden.exists(), f'forbidden boundary/map artifact shipped: {forbidden}'
for p in dist.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.geojson', '.topojson'}:
        raise AssertionError(f'boundary geometry shipped: {p}')
for p in dist.rglob('*'):
    if p.is_file() and p.suffix == '.js':
        txt = p.read_text(encoding='utf-8')
        assert 'gz_districts_11' not in txt and 'assets/maps' not in txt, f'boundary/map reference in {p}'

# 2) metrics data contract
m = json.loads((dist / 'assets' / 'data' / 'district_metrics.json').read_text(encoding='utf-8'))
assert len(m['districts']) == 11, 'must have 11 districts'
assert len(m['metrics']) == 8, 'must have 8 metrics'
assert len({str(d['adcode']) for d in m['districts']}) == 11
assert len({x['id'] for x in m['metrics']}) == 8
assert not m['meta'].get('_fixture')
assert m['meta']['focus']['status'] == 'not_configured'
for d in m['districts']:
    assert set(d['values'].keys()) == {x['id'] for x in m['metrics']}, d['name']
assert sum(len(d['values']) for d in m['districts']) == 88, 'expected 88 metric values'
for metric in m['metrics']:
    for key in ('label', 'unit', 'years', 'numerator', 'denominator', 'source', 'qualityNote'):
        assert metric.get(key), f'{metric["id"]} missing {key}'

# 3) panel provider contract
p = (dist / 'district-panel-provider.js').read_text(encoding='utf-8')
for needle in ['ResearchMapSlot.register', 'district-panel-provider', 'district-grid', 'panel-metric', 'gz-linked-bars', 'data/']:
    assert needle in p or needle in (dist / 'district-panel-provider.js').name, needle
assert 'assets/maps' not in p
assert 'gz_districts_11' not in p
assert 'gz-district-map' not in p
assert 'fetch(' in p and 'district_metrics.json' in p

# 4) original research content contract is delegated to verify_content.py; basic checks here
content = json.loads((dist / 'content.json').read_text(encoding='utf-8'))
paras = [b for c in content['chapters'] for b in c['blocks'] if b['type'] == 'paragraph']
assert len(paras) == 89, len(paras)
assert sum(len(b['text']) for b in paras) == 13766
assert len(content['references']) == 19
assert [c['title'] for c in content['chapters']] == ['研究介绍', '研究区域', '研究方法', '研究结果', '讨论与总结']
assert (root / 'dist' / 'index.html').read_text(encoding='utf-8').count('district-panel-provider.js') == 1
assert (root / 'dist' / 'district-panel.css').is_file()
overview = (root / 'dist' / 'overview.js').read_text(encoding='utf-8')
assert '区级比较' in overview
assert 'district-panel' not in overview
assert 'district-panel-provider.js' in (root / 'dist' / 'index.html').read_text(encoding='utf-8')

print('PASS: 安全面板候选：无边界几何/地图资源；11区8指标88值；数据来源/单位/年份/质量字段完整；无地图引用；89段/13766字符/19文献')


