# TEST_RESULTS — 本轮真实测试证据

| 文件 | 内容 |
|---|---|
| `e2e-results.json` | 安全候选 20 项真实浏览器 E2E 的逐项结果、汇总、页面信息、移动端读数 |
| `e2e-failure-missing.json` | 5 项失败隔离/缺失值测试结果 |
| `npm-check.log` | `npm run check` 完整输出（六项 PASS，退出码 0；Windows/Python/UTF-8 适配说明见下） |
| `e2e_panel.cjs` | 可复跑 E2E 脚本（默认 `http://127.0.0.1:3020`） |
| `e2e_failure_missing.cjs` | 可复跑失败/缺失测试脚本 |
| `screenshots/desktop-panel-default.png` | 桌面 1440×900 默认面板 |
| `screenshots/desktop-panel-selected.png` | 桌面选中黄埔区 + 详情 |
| `screenshots/mobile-panel.png` | 移动 390×844（物理 780×1688） |

## 本轮结果

- E2E：**20/20 通过，0 失败**；控制台 0 error、资源失败 0、外部请求 0。
- 失败/缺失：**5/5 通过**；阻断数据资源→降级/正文可读；恢复；缺失夹具显示“缺失”而非 0；恢复真实数据。
- 静态检查：`npm run check` 六项 PASS。
- 部署资源：无边界 GeoJSON/地图组件/边界请求。

## 环境

- Windows 11 / Microsoft Edge 156.0.4314.42 / Node 24.19.0
- Node 24 内置 WebSocket + Edge CDP；`Emulation.setDeviceMetricsOverride` 实现桌面 1440×900 与移动 390×844（mobile:true, dpr2）；`Input.dispatchMouseEvent/TouchEvent/KeyEvent` 真实输入；`Page.captureScreenshot` 截图。
- `npm run check` 需 Python3；本机 `python3` 只有 Microsoft Store 别名，且默认 GBK，故使用临时 `python3` 转发器 + `PYTHONUTF8=1`。**未修改项目源码来绕过该环境问题。**

## 复跑

```powershell
# 先启动站点（示例端口 3020）
cd ..\site
node scripts\serve.mjs --port 3020
# 另开终端
cd ..
node TEST_RESULTS\e2e_panel.cjs http://127.0.0.1:3020
node TEST_RESULTS\e2e_failure_missing.cjs http://127.0.0.1:3020
```

> 本目录只保存本轮安全候选的测试；原 V4 地图版的 28/28 与模块 48/48 属历史结果，未混入本轮数字。
