/* Independent CDP E2E for the final safe district comparison panel.
 * Usage: node TEST_RESULTS/e2e_panel.cjs [baseUrl]
 */
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const PORT = 9488;
const BASE = process.argv[2] || 'http://127.0.0.1:3020';
const SITE = path.resolve(__dirname, '..', 'site');
const OUT = path.join(__dirname, 'screenshots');
const profile = path.join(os.tmpdir(), 'v4-final-e2e-profile');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = [];
const ok = (name, pass, detail = '') => results.push({ name, pass: !!pass, detail: String(detail).slice(0, 400) });

class CDP {
 constructor(u) { this.u = u; this.i = 0; this.p = new Map(); this.errors = []; this.failed = []; this.external = []; this.requests = []; }
 async connect() {
  this.ws = new WebSocket(this.u);
  await new Promise((res, rej) => { this.ws.addEventListener('open', res); this.ws.addEventListener('error', rej); });
  this.ws.addEventListener('message', e => {
   const m = JSON.parse(e.data);
   if (m.id && this.p.has(m.id)) { const q = this.p.get(m.id); this.p.delete(m.id); m.error ? q.reject(new Error(JSON.stringify(m.error))) : q.resolve(m.result); return; }
   if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') this.errors.push((m.params.args || []).map(a => a.value || a.description || '').join(' '));
   if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') this.errors.push(m.params.entry.text);
   if (m.method === 'Network.loadingFailed') this.failed.push(m.params);
   if (m.method === 'Network.requestWillBeSent') {
    const url = m.params.request.url; this.requests.push(url);
    if (/^https?:/i.test(url) && !url.startsWith(BASE)) this.external.push(url);
   }
  });
 }
 send(method, params = {}) { const id = ++this.i; return new Promise((resolve, reject) => { this.p.set(id, { resolve, reject }); this.ws.send(JSON.stringify({ id, method, params })); }); }
 async eval(expr) { const r = await this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails)); return r.result.value; }
 async mouse(x, y, type = 'mouseMoved', extra = {}) { await this.send('Input.dispatchMouseEvent', { type, x, y, button: type === 'mouseMoved' ? 'none' : 'left', clickCount: type === 'mousePressed' || type === 'mouseReleased' ? 1 : 0, buttons: type === 'mousePressed' ? 1 : 0, ...extra }); }
 async clickAt(x, y) { await this.mouse(x, y, 'mouseMoved'); await this.mouse(x, y, 'mousePressed'); await sleep(30); await this.mouse(x, y, 'mouseReleased'); await sleep(260); }
 async key(k) { const base = { key: k, code: k, windowsVirtualKeyCode: k === 'Enter' ? 13 : k === 'Escape' ? 27 : 0, nativeVirtualKeyCode: k === 'Enter' ? 13 : k === 'Escape' ? 27 : 0 }; if (k === 'Enter') { base.text = '\\r'; base.unmodifiedText = '\\r'; } await this.send('Input.dispatchKeyEvent', { type: 'keyDown', ...base }); await this.send('Input.dispatchKeyEvent', { type: 'keyUp', ...base, text: undefined }); await sleep(260); }
 close() { try { this.ws.close(); } catch {} }
}
async function waitFor(c, expr, timeout = 15000, step = 250) {
 const t0 = Date.now();
 while (Date.now() - t0 < timeout) { try { if (await c.eval(expr)) return true; } catch {} await sleep(step); }
 return false;
}
async function center(c, selector) {
 return await c.eval(`(function(){const el=document.querySelector(${JSON.stringify(selector)}); if(!el)return null; el.scrollIntoView({block:'center',inline:'center'}); const r=el.getBoundingClientRect(); return {x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height};})()`);
}
async function clickSel(c, selector) { const p = await center(c, selector); if (!p) return false; await c.clickAt(p.x, p.y); return true; }

(async () => {
 fs.rmSync(profile, { recursive: true, force: true });
 fs.mkdirSync(OUT, { recursive: true });
 const metrics = JSON.parse(fs.readFileSync(path.join(SITE, 'dist/assets/data/district_metrics.json'), 'utf8'));
 const vd = JSON.parse(fs.readFileSync(path.join(SITE, 'dist/visual-data.json'), 'utf8'));
 const expectedOrder = vd.density.rows.map(r => r.district);
 const expectedVals = Object.fromEntries(metrics.metrics.map(x => [x.id, Object.fromEntries(metrics.districts.map(d => [d.adcode, d.values[x.id]]))]));
 const expectedDecimals = Object.fromEntries(metrics.metrics.map(x => [x.id, x.decimals]));

 const proc = spawn(EDGE, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--remote-debugging-port=' + PORT, '--user-data-dir=' + profile, 'about:blank'], { stdio: 'ignore' });
 try {
  let v = null;
  for (let i = 0; i < 80; i++) { try { v = await (await fetch('http://127.0.0.1:' + PORT + '/json/version')).json(); break; } catch { await sleep(250); } }
  if (!v) throw new Error('CDP not ready');
  const page = await (await fetch('http://127.0.0.1:' + PORT + '/json/new?about:blank', { method: 'PUT' })).json();
  const c = new CDP(page.webSocketDebuggerUrl);
  await c.connect(); await c.send('Page.enable'); await c.send('Runtime.enable'); await c.send('Log.enable'); await c.send('Network.enable');
  await c.send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 900, deviceScaleFactor: 1, mobile: false });
  await c.send('Page.navigate', { url: BASE + '/#s-4-1' });
  const ready = await waitFor(c, `(function(){return document.querySelectorAll('.district-card').length===11&&document.querySelectorAll('.gz-linked-row').length===11&&document.querySelectorAll('.panel-metric').length===8})()`, 20000);
  ok('A1 panel-ready-11-cards-11-bars-8-metrics', ready);

  const info = await c.eval(`(function(){
    return {title:document.title,hash:location.hash,
      chapters:[...document.querySelectorAll('.track-section')].map(s=>s.id),
      nav:[...document.querySelectorAll('#chapter-nav>a')].map(a=>a.textContent.trim()),
      cards:document.querySelectorAll('.district-card').length,
      bars:document.querySelectorAll('.gz-linked-row').length,
      metrics:document.querySelectorAll('.panel-metric').length,
      maps:document.querySelectorAll('gz-district-map').length,
      geojsonRequested:performance.getEntriesByType('resource').some(r=>/\\.geojson/i.test(r.name)),
      mapDirRequested:performance.getEntriesByType('resource').some(r=>/assets\\/maps/i.test(r.name)),
      figures:document.querySelectorAll('#report-content .report-figure').length,
      references:document.querySelectorAll('#reference-list li').length,
      ch2Images:document.querySelectorAll('#chapter-2 .report-figure').length,
      v2Record:!!document.querySelector('#v2-density-record'),
      v2Rows:document.querySelectorAll('#v2-density-record .density-row').length,
      focusBadge:document.querySelectorAll('.badge-focus').length,
      quality:(document.querySelector('.map-quality')||{}).textContent,
      panelKicker:(document.querySelector('.panel-kicker')||{}).textContent,
      panelTitle:(document.querySelector('.panel-title')||{}).textContent,
      panelSub:(document.querySelector('.panel-sub')||{}).textContent,
      legend:(document.querySelector('.panel-legend')||{}).textContent,
      status:(document.querySelector('#district-panel-selection')||{}).textContent,
      metricPressed:[...document.querySelectorAll('.panel-metric[aria-pressed="true"]')].map(e=>e.dataset.metric),
      cardOrder:[...document.querySelectorAll('.district-card')].map(e=>e.querySelector('.district-name').textContent),
      barOrder:[...document.querySelectorAll('.gz-linked-row .district-label')].map(e=>e.textContent)
    }})()`);
  ok('A2 structure', ['home','chapter-1','chapter-2','chapter-3','chapter-4','chapter-5','references'].every(x => info.chapters.includes(x)) && info.nav.length === 7, JSON.stringify(info.chapters));
  ok('A3 no boundary/map resources', !info.geojsonRequested && !info.mapDirRequested && info.maps === 0, JSON.stringify({geo: info.geojsonRequested, mapdir: info.mapDirRequested, maps: info.maps}));
  ok('A4 original figures/references/v2 record', info.figures === 4 && info.references === 19 && info.ch2Images === 2 && info.v2Record && info.v2Rows === 11, JSON.stringify({figures: info.figures, refs: info.references, ch2: info.ch2Images, v2: info.v2Record, rows: info.v2Rows}));
  ok('A5 fixed orders', info.cardOrder.join(',') === metrics.districts.map(d => d.name).join(',') && info.barOrder.join(',') === expectedOrder.join(','), JSON.stringify({cards: info.cardOrder, bars: info.barOrder}));
  ok('A6 non-geographic labels', /非地理示意/.test(info.panelKicker + info.panelTitle + info.panelSub) && /不使用行政区边界/.test(info.quality) && !/地图加载/.test(info.status), (info.panelKicker + '|' + info.panelTitle + '|' + info.panelSub).slice(0, 220));
  ok('A7 no focus-region', info.focusBadge === 0, String(info.focusBadge));

  // 89 paragraph text presence (custom framework items included)
  const textCheck = await c.eval(`(async function(){
    const c=await fetch('content.json').then(r=>r.json());
    const ps=[];for(const ch of c.chapters)for(const b of ch.blocks)if(b.type==='paragraph')ps.push(b.text.trim());
    const body=document.querySelector('#report-content').textContent.replace(/\\s+/g,' ');
    return {total:ps.length,missing:ps.filter(t=>!body.includes(t.replace(/\\s+/g,' '))).length};
  })()`);
  ok('A8 89-paragraph-text-present', textCheck.total === 89 && textCheck.missing === 0, JSON.stringify(textCheck));

  // 8 metrics via real clicks; values/cards/bars/legend
  const metricFailures = [];
  for (const mm of metrics.metrics) {
   const clicked = await clickSel(c, `.panel-metric[data-metric="${mm.id}"]`);
   await sleep(220);
   const read = await c.eval(`(function(){
     return {pressed:[...document.querySelectorAll('.panel-metric[aria-pressed="true"]')].map(e=>e.dataset.metric),
       cards:[...document.querySelectorAll('.district-card')].map(e=>({code:e.dataset.adcode,value:e.querySelector('.district-value').textContent.trim(),unit:e.querySelector('.district-unit').textContent.trim()})),
       bars:[...document.querySelectorAll('.gz-linked-row')].map(e=>({code:e.dataset.adcode,value:e.dataset.value,label:e.querySelector('.district-label').textContent.trim()})),
       title:document.querySelector('.gz-bars-title').textContent,unit:document.querySelector('.gz-linked-bars .chart-unit').textContent,
       legend:document.querySelector('.panel-legend').textContent};
   })()`);
   const cardVals = read.cards.every(x => x.value === (expectedVals[mm.id][x.code] === null ? '缺失' : Number(expectedVals[mm.id][x.code]).toFixed(expectedDecimals[mm.id])));
   const barVals = read.bars.every(x => x.value === String(expectedVals[mm.id][x.code]));
   const metaOk = read.pressed.join(',') === mm.id && read.title.includes(mm.label) && read.unit.includes(mm.unit) && read.legend.includes(mm.unit) && read.legend.includes(mm.qualityNote.slice(0, 10));
   if (!(clicked && cardVals && barVals && metaOk)) metricFailures.push({id: mm.id, clicked, cardVals, barVals, metaOk});
  }
  ok('B1 8-metrics-real-click-values', metricFailures.length === 0, JSON.stringify(metricFailures));
  await clickSel(c, '.panel-metric[data-metric="bedDensity"]'); await sleep(220);

  // card select real
  const card = await center(c, '.district-card[data-adcode="440103"]');
  if (card) await c.clickAt(card.x, card.y);
  let sel = await c.eval(`(function(){return {card:[...document.querySelectorAll('.district-card[aria-pressed="true"]')].map(e=>e.dataset.adcode),bar:[...document.querySelectorAll('.gz-linked-row[aria-pressed="true"]')].map(e=>e.dataset.adcode),detail:document.querySelector('.district-detail').textContent,status:document.querySelector('#district-panel-selection').textContent}})()`);
  ok('C1 card-click-selects-detail-and-bar', sel.card.join(',') === '440103' && sel.bar.join(',') === '440103' && sel.detail.includes('荔湾区') && sel.status.includes('荔湾区'), JSON.stringify(sel).slice(0, 300));

  // bar select real
  const bar = await center(c, '.gz-linked-row[data-adcode="440104"]');
  if (bar) await c.clickAt(bar.x, bar.y);
  sel = await c.eval(`(function(){return {card:[...document.querySelectorAll('.district-card[aria-pressed="true"]')].map(e=>e.dataset.adcode),bar:[...document.querySelectorAll('.gz-linked-row[aria-pressed="true"]')].map(e=>e.dataset.adcode),detail:document.querySelector('.district-detail').textContent}})()`);
  ok('C2 bar-click-selects-detail-and-card', sel.card.join(',') === '440104' && sel.bar.join(',') === '440104' && sel.detail.includes('越秀区'), JSON.stringify(sel).slice(0, 300));

  // reset real
  await clickSel(c, '.panel-reset'); await sleep(300);
  const reset = await c.eval(`(function(){return {pressedCard:document.querySelectorAll('.district-card[aria-pressed="true"]').length,pressedBar:document.querySelectorAll('.gz-linked-row[aria-pressed="true"]').length,metric:[...document.querySelectorAll('.panel-metric[aria-pressed="true"]')].map(e=>e.dataset.metric),status:document.querySelector('#district-panel-selection').textContent}})()`);
  ok('C3 reset-clears-selection-and-default-metric', reset.pressedCard === 0 && reset.pressedBar === 0 && reset.metric.join(',') === metrics.meta.defaultMetric, JSON.stringify(reset).slice(0, 260));

  // keyboard: focus a card, Enter select, Esc clear
  const focusDbg = await c.eval(`(function(){const el=document.querySelector('.district-card[data-adcode="440105"]');el.focus();return {ad:document.activeElement&&document.activeElement.dataset?document.activeElement.dataset.adcode:null,tag:document.activeElement&&document.activeElement.tagName,hasFocus:document.hasFocus()}})()`);
  await c.key('Enter');
  const keySel = await c.eval(`document.querySelectorAll('.district-card[aria-pressed="true"]').length`);
  const afterKey = await c.eval(`(function(){return {ad:document.activeElement&&document.activeElement.dataset?document.activeElement.dataset.adcode:null,pressed:document.querySelectorAll('.district-card[aria-pressed="true"]').length}})()`);
  await c.key('Escape'); await sleep(200);
  const keyReset = await c.eval(`document.querySelectorAll('.district-card[aria-pressed="true"]').length`);
  ok('C4 keyboard-enter-select-escape-clear', keySel === 1 && keyReset === 0, JSON.stringify({keySel, keyReset, focusDbg, afterKey}));

  // chapter history + single panel
  const histBefore = await c.eval(`(function(){window.scrollTo(0,Math.min(600,document.documentElement.scrollHeight-800));return {scroll:Math.round(scrollY),metric:[...document.querySelectorAll('.panel-metric[aria-pressed="true"]')].map(e=>e.dataset.metric)}})()`);
  await clickSel(c, 'a[href="#chapter-2"]'); await sleep(550);
  const at2 = await c.eval(`({ch2:!document.querySelector('#chapter-2').hidden,ch4:!document.querySelector('#chapter-4').hidden,cards:document.querySelectorAll('.district-card').length})`);
  await c.eval('history.back()'); await sleep(750);
  const back = await c.eval(`(function(){return {scroll:Math.round(scrollY),ch4:!document.querySelector('#chapter-4').hidden,ch2:!document.querySelector('#chapter-2').hidden,cards:document.querySelectorAll('.district-card').length,metric:[...document.querySelectorAll('.panel-metric[aria-pressed="true"]')].map(e=>e.dataset.metric)}})()`);
  await c.eval('history.forward()'); await sleep(750);
  const fwd = await c.eval(`({ch2:!document.querySelector('#chapter-2').hidden,ch4:!document.querySelector('#chapter-4').hidden})`);
  ok('D1 chapter-history-restore-and-single-panel', at2.ch2 && !at2.ch4 && at2.cards === 11 && back.ch4 && !back.ch2 && back.cards === 11 && back.scroll > 0 && fwd.ch2 && !fwd.ch4, JSON.stringify({histBefore, at2, back, fwd}).slice(0, 500));

  // screenshots desktop
  await c.eval('history.back()'); await sleep(700);
  await c.send('Page.captureScreenshot', { format: 'png', fromSurface: true }).then(s => fs.writeFileSync(path.join(OUT, 'desktop-panel-default.png'), Buffer.from(s.data, 'base64')));
  await c.eval(`document.querySelector('.district-card[data-adcode="440112"]').click()`); await sleep(300);
  await c.send('Page.captureScreenshot', { format: 'png', fromSurface: true }).then(s => fs.writeFileSync(path.join(OUT, 'desktop-panel-selected.png'), Buffer.from(s.data, 'base64')));

  // mobile 390
  await c.send('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
  await c.send('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
  await c.send('Page.navigate', { url: BASE + '/#s-4-1' });
  const mobReady = await waitFor(c, `(function(){return document.querySelectorAll('.district-card').length===11&&document.querySelectorAll('.gz-linked-row').length===11})()`, 20000);
  await sleep(500);
  const mob = await c.eval(`(function(){const g=document.querySelector('.district-grid').getBoundingClientRect();return {innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,gridWidth:Math.round(g.width),cards:document.querySelectorAll('.district-card').length,bars:document.querySelectorAll('.gz-linked-row').length}})()`);
  ok('E1 mobile-390-no-horizontal-overflow', mobReady && mob.scrollWidth <= mob.clientWidth + 1 && mob.gridWidth <= 390, JSON.stringify(mob));
  const mc = await center(c, '.district-card[data-adcode="440105"]');
  if (mc) { await c.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: mc.x, y: mc.y }] }); await sleep(40); await c.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await sleep(400); }
  const mobSel = await c.eval(`({card:[...document.querySelectorAll('.district-card[aria-pressed="true"]')].map(e=>e.dataset.adcode),bar:[...document.querySelectorAll('.gz-linked-row[aria-pressed="true"]')].map(e=>e.dataset.adcode)})`);
  ok('E2 mobile-touch-card-selects', mobSel.card.join(',') === '440105' && mobSel.bar.join(',') === '440105', JSON.stringify(mobSel));
  await c.send('Page.captureScreenshot', { format: 'png', fromSurface: true }).then(s => fs.writeFileSync(path.join(OUT, 'mobile-panel.png'), Buffer.from(s.data, 'base64')));

  // console/network
  ok('F1 console-script-errors-zero', c.errors.length === 0, c.errors.join(' | ').slice(0, 400));
  const failedReal = c.failed.filter(f => f.errorText && !/ERR_ABORTED/.test(f.errorText));
  ok('F2 resource-failures-zero', failedReal.length === 0, JSON.stringify(failedReal).slice(0, 300));
  ok('F3 no-external-http', c.external.length === 0, c.external.join(',').slice(0, 300));
  ok('F4 only-local-data-no-boundary', c.requests.every(u => !/assets\/maps|\.geojson/i.test(u)), c.requests.filter(u => /assets\/maps|\.geojson/i.test(u)).join(','));

  const failed = results.filter(r => !r.pass);
  const summary = { total: results.length, pass: results.length - failed.length, fail: failed.length, failures: failed, errors: c.errors, failedRequests: failedReal.length, externalRequests: c.external.length };
  fs.writeFileSync(path.join(__dirname, 'e2e-results.json'), JSON.stringify({ summary, results, info, textCheck, mob }, null, 1));
  console.log(JSON.stringify(summary, null, 1));
  c.close();
 } finally { proc.kill(); }
})().catch(e => { console.error('E2E FAIL', e); process.exit(1); });


