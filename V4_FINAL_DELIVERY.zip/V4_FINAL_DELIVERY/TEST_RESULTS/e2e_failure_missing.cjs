/* Failure isolation + missing-value test for the safe panel. */
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const PORT = 9491;
const BASE = process.argv[2] || 'http://127.0.0.1:3020';
const fixturePath = 'D:\\筑工杯数据获取\\广州11区交互地图模块_20261028\\data\\_fixture_missing.json';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = [];
const ok = (name, pass, detail = '') => results.push({ name, pass: !!pass, detail: String(detail).slice(0, 400) });
class CDP {
 constructor(u) { this.u = u; this.i = 0; this.p = new Map(); this.errors = []; }
 async connect() { this.ws = new WebSocket(this.u); await new Promise((a, b) => { this.ws.addEventListener('open', a); this.ws.addEventListener('error', b); }); this.ws.addEventListener('message', e => { const m = JSON.parse(e.data); if (m.id && this.p.has(m.id)) { const q = this.p.get(m.id); this.p.delete(m.id); m.error ? q.reject(new Error(JSON.stringify(m.error))) : q.resolve(m.result); } else if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') { this.errors.push((m.params.args || []).map(a => a.value || a.description || '').join(' ')); } else if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') { this.errors.push(m.params.entry.text); } }); }
 send(method, params = {}) { const id = ++this.i; return new Promise((resolve, reject) => { this.p.set(id, { resolve, reject }); this.ws.send(JSON.stringify({ id, method, params })); }); }
 async eval(expr) { const r = await this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails)); return r.result.value; }
 close() { try { this.ws.close(); } catch {} }
}
async function waitFor(c, expr, timeout = 15000) { const t = Date.now(); while (Date.now() - t < timeout) { try { if (await c.eval(expr)) return true; } catch {} await sleep(250); } return false; }
(async () => {
 const profile = path.join(os.tmpdir(), 'v4-panel-failure-profile'); fs.rmSync(profile, { recursive: true, force: true });
 const out = path.join(__dirname, 'e2e-failure-missing.json');
 const proc = spawn(EDGE, ['--headless=new', '--disable-gpu', '--no-first-run', '--remote-debugging-port=' + PORT, '--user-data-dir=' + profile, 'about:blank'], { stdio: 'ignore' });
 try {
  let v; for (let i = 0; i < 80; i++) { try { v = await (await fetch('http://127.0.0.1:' + PORT + '/json/version')).json(); break; } catch { await sleep(250); } }
  const page = await (await fetch('http://127.0.0.1:' + PORT + '/json/new?about:blank', { method: 'PUT' })).json();
  const c = new CDP(page.webSocketDebuggerUrl); await c.connect(); await c.send('Page.enable'); await c.send('Runtime.enable'); await c.send('Network.enable'); await c.send('Log.enable');
  await c.send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 900, deviceScaleFactor: 1, mobile: false });
  // 1) block data
  await c.send('Network.setBlockedURLs', { urls: ['*assets/data/*'] });
  await c.send('Page.navigate', { url: BASE + '/#s-4-1' }); await sleep(4500);
  const failed = await c.eval(`(function(){return {fallback:document.querySelectorAll('.map-fallback').length,fallbackText:(document.querySelector('.map-fallback')||{}).textContent||'',cards:document.querySelectorAll('.district-card').length,paras:document.querySelectorAll('#report-content p[id^="source-p-"]').length,ch4:!document.querySelector('#chapter-4').hidden}})()`);
  ok('G1 data-failure-fallback-and-report-readable', failed.fallback > 0 && /不可用|仍可/.test(failed.fallbackText) && failed.cards === 0 && failed.paras >= 82 && failed.ch4, JSON.stringify(failed).slice(0, 340));
  // 2) recover after reload
  await c.send('Network.setBlockedURLs', { urls: [] });
  await c.send('Page.reload', { ignoreCache: true });
  const recovered = await waitFor(c, `document.querySelectorAll('.district-card').length===11`, 20000);
  ok('G2 data-recovery-after-reload', recovered);
  // 3) injected fixture missing values
  const fixture = JSON.parse(fs.readFileSync(fixturePath, 'utf8'));
  const inject = await c.send('Page.addScriptToEvaluateOnNewDocument', { source: 'window.__DISTRICT_PANEL_FIXTURE__=' + JSON.stringify(fixture) + ';' });
  await c.send('Page.navigate', { url: BASE + '/?fixture=1#s-4-1' });
  await sleep(1200);
  await c.send('Page.reload', { ignoreCache: true });
  const fixReady = await waitFor(c, `document.querySelectorAll('.district-card').length===11`, 20000);
  const injectDbg = await c.eval(`({hasFixture:!!window.__DISTRICT_PANEL_FIXTURE__,fixtureCount:window.__DISTRICT_PANEL_FIXTURE__?window.__DISTRICT_PANEL_FIXTURE__.districts.length:0,missing:document.querySelectorAll('.district-card.is-missing').length})`);
  await sleep(400);
  const fix = await c.eval(`(function(){
    const cards=[...document.querySelectorAll('.district-card')];
    const missing=cards.filter(c=>c.classList.contains('is-missing'));
    const card=missing[0]||cards[0];
    card.click();
    return {ready:cards.length===11,missing:missing.length,missingNames:missing.map(c=>c.querySelector('.district-name').textContent),
      fixtureBanner:(document.querySelector('.panel-fixture')||{}).textContent||'',
      value:card.querySelector('.district-value').textContent.trim(),
      detail:document.querySelector('.district-detail').textContent,
      legend:document.querySelector('.panel-legend').textContent};
  })()`);
  ok('G3 fixture-missing-rendered-not-zero', fixReady && injectDbg.hasFixture && fix.missing === 2 && fix.value === '缺失' && /（缺失）|缺失/.test(fix.detail) && !/0\s*床/.test(fix.detail) && /缺失/.test(fix.legend) && /测试夹具/.test(fix.fixtureBanner), JSON.stringify({injectDbg, missing: fix.missing, names: fix.missingNames, value: fix.value, detail: fix.detail.slice(0, 80)}).slice(0, 380));
  // clean injected script and reload real data
  await c.send('Page.removeScriptToEvaluateOnNewDocument', { identifier: inject.identifier });
  await c.send('Page.navigate', { url: BASE + '/#s-4-1' });
  const real = await waitFor(c, `document.querySelectorAll('.district-card.is-missing').length===0&&document.querySelectorAll('.district-card').length===11`, 20000);
  ok('G4 restore-real-data-no-missing', real);
  ok('G5 no-console-errors', c.errors.length === 0, c.errors.join(' | ').slice(0, 300));
  const failedTests = results.filter(r => !r.pass);
  fs.writeFileSync(out, JSON.stringify({ summary: { total: results.length, pass: results.length - failedTests.length, fail: failedTests.length, failures: failedTests, consoleErrors: c.errors }, results, failed, fix }, null, 1));
  console.log(JSON.stringify({ total: results.length, pass: results.length - failedTests.length, fail: failedTests.length, failures: failedTests, errors: c.errors }, null, 1));
  c.close();
 } finally { proc.kill(); }
})().catch(e => { console.error('FAIL', e); process.exit(1); });


