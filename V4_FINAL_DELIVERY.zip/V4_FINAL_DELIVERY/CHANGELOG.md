# CHANGELOG — V4 安全候选（相对 V4 地图版）

基准：`guangzhou-v3-map-integration-source.zip`（SHA-256 `4EF8E83F7DBB08B184227D49C52FFDEE21600EE5B0123A5870291C5CD87F2388`）
候选：`V4_FINAL_DELIVERY/site`（V4-SAFE）

## 新增

| 文件 | 原因 |
|---|---|
| `site/dist/district-panel-provider.js` | 非地理 11 区比较面板：11 卡、8 指标、区级详情、联动条形、重置、键盘、移动端、缺失值；不加载边界/地图 |
| `site/dist/district-panel.css` | 面板专属样式（米白/深绿、响应式、卡片/详情/条形），不穿透 Shadow DOM |
| `site/dist/assets/data/district_metrics.json` | 原本的指标数据移动到无边界目录；数值未改 |
| `site/scripts/verify_district_panel.py` | 验证无边界/地图资源、11区8指标88值、字段完整、原文89段 |
| `site/scripts/verify_panel_slot.mjs` | 由原 `verify_map_slot.mjs` 改名，验证泛用 slot 的 fail-isolation/cleanup |
| `site/CANDIDATE_STATE.json` | 明确本地候选状态；替代原 `DELIVERY_STATE.json`，避免误称已保存版本 |
| `TEST_RESULTS/e2e_panel.cjs`、`e2e_failure_missing.cjs` | 本轮可复跑测试脚本 |
| `TEST_RESULTS/e2e-results.json`、`e2e-failure-missing.json`、`npm-check.log`、`screenshots/` | 本轮测试证据 |
| 根目录 `FINAL_ACCEPTANCE_REPORT.md`、`CHANGELOG.md`、`KNOWN_LIMITATIONS.md`、`RELEASE_CHECKLIST.md`、`HANDOFF.md`、`DATA_SOURCES_AND_COMPLIANCE.md` | 交付说明、验收、限制与发布准备 |

## 修改

| 文件 | 修改 |
|---|---|
| `site/dist/index.html` | 引用 `district-panel.css`/`district-panel-provider.js`；V4 候选标识；4.1 文案改为非地理比较面板 |
| `site/dist/overview.js` | 4.1 面板说明改为“非地理示意、不使用行政区边界”；数据质量提示更新；保留原文/原图/原 V3 床位图 |
| `site/dist/map-slot.js` | fallback 文案改为“区级比较面板”；provider 类型错误文案更新 |
| `site/package.json` | 版本 0.3.1 → 0.4.0；检查命令改为面板/数据/内容/视图检查，移除地图资源检查 |
| `site/scripts/qa-map-host.html` | 验收视口标题/说明改为区级比较面板 |
| `site/README.md` | 说明安全候选、运行方式、测试与状态 |

## 删除（仅最终部署目录）

| 文件/目录 | 原因 |
|---|---|
| `site/dist/assets/maps/gz_districts_11.geojson` | 边界许可/审图未闭合，停止再分发 |
| `site/dist/assets/maps/gz-district-map.js` | 地图组件依赖边界数据，本候选不使用 |
| `site/dist/assets/maps/district_metrics.json`（旧路径） | 指标数据移至 `dist/assets/data/`，避免与边界目录混淆 |
| `site/dist/map-provider.js`、`site/dist/map-provider.css` | 被非地理面板 provider/CSS 替代 |
| `site/scripts/verify_map_integration.py`、`verify_map_slot.mjs` | 由面板检查脚本替代 |
| `site/DELIVERY_STATE.json` | 原 V4 的保存状态记录不再适用于安全候选；候选状态写入 `CANDIDATE_STATE.json`，原始记录见 HANDOFF/原交付包 |

> 原始 V4 交付包本身**未被修改**；仍位于 `D:\webDownload\guangzhou-v3-map-integration-source.zip`（SHA-256 见上）。原 V4 地图组件/边界资源未在本最终包再分发。

## 未改动

`dist/content.json`、`dist/visual-data.json`、`assets/image1-4.png`、章节路由、引文/参考文献、研究结论、原始人口/床位/机构/饭堂/医疗数据、指标口径。
