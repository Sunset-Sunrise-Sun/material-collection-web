# 筑工杯广州 AI 养老研究成果网页 — V4 安全候选最终交付

**交付时间**：2026-10-29（Asia/Shanghai）
**研究对象**：《从场景清单到审慎试点：广州市人工智能养老应用的需求匹配、证据成熟度与推广条件研究》
**候选版本**：V4-SAFE（非地理的 11 区区级比较面板）
**线上状态**：**原线上仍为 V3；本候选未保存到 Sites、未发布、未回滚。**

---

## 1. 本次交付是什么

原 V4 已接入广州 11 区 2.5D 行政区地图，但地图边界来自 DataV GeoAtlas（数据源为高德开放平台），官方仅说明“仅供学习和交流使用”；边界许可/再分发、坐标系和审图号在发布前未闭合。为不带着争议边界发布，本次**实际实施了安全替代方案**：

- **从部署目录移除行政区边界 GeoJSON 与地图组件**；
- **新增非地理的广州 11 区区级比较面板**（卡片 + 区级详情 + 联动条形 + 指标切换 + 键盘操作 + 移动端）；
- 保留原报告五章/参考文献/原文/原图/原 V3 床位图/数据质量与边界提示；
- 面板明确标注“**非地理示意：不绘制行政区边界、不叠加底图、不提供地理定位或量测**”；
- **未修改**原始研究数据、指标口径或报告结论。

> 本候选不是“地图”，不能称其为行政区地图；它用区名作为统计单元，只做数值比较。原 V4 地图源码包仍保留在交付方外部目录，未在本最终包中再分发边界数据。

---

## 2. 目录

```
V4_FINAL_DELIVERY/
├─ README.md                         本文件
├─ FINAL_ACCEPTANCE_REPORT.md        最终验收报告（本轮实际测试）
├─ CHANGELOG.md                      相对 V4 的实际修改
├─ KNOWN_LIMITATIONS.md              仍未闭合事项与解释边界
├─ RELEASE_CHECKLIST.md              正式发布前最后检查清单
├─ HANDOFF.md                        线上/Sites状态、阻塞与最短后续操作
├─ DATA_SOURCES_AND_COMPLIANCE.md    数据来源、边界处理与合规依据
├─ site/                             可运行的最终候选网页项目
│  ├─ dist/                          静态站点（无边界GeoJSON、无地图组件）
│  │  ├─ assets/data/district_metrics.json
│  │  ├─ district-panel-provider.js
│  │  ├─ district-panel.css
│  │  └─ ...（原报告正文/图表/图片/样式）
│  ├─ scripts/                        serve.mjs 与项目检查脚本
│  ├─ docs/                           保留的历史交付文档（原地图相关文档仅作历史参考）
│  ├─ CANDIDATE_STATE.json            本候选取代原 DELIVERY_STATE 的状态记录
│  ├─ .openai/hosting.json            原 Sites 项目 ID（仅供后续授权发布使用）
│  ├─ package.json
│  └─ README.md                       站点项目说明
└─ TEST_RESULTS/                     本轮真实测试结果、日志、截图与测试脚本
   ├─ e2e-results.json                20 项真实浏览器 E2E
   ├─ e2e-failure-missing.json        5 项失败隔离/缺失值测试
   ├─ npm-check.log                   项目自带检查完整日志
   ├─ screenshots/                    桌面/移动截图
   └─ e2e_panel.cjs / e2e_failure_missing.cjs
```

---

## 3. 运行方式

需要 Node.js 18+。进入 `site/`：

```powershell
cd D:\筑工杯数据获取\V4_FINAL_DELIVERY\site
npm run dev
# 打开 http://localhost:3000/#s-4-1
```

也可直接静态服务：

```powershell
python -m http.server 3000 --directory dist
# 打开 http://localhost:3000/#s-4-1
```

必须通过 HTTP 访问，不能直接双击 `dist/index.html`。

### 检查

```powershell
cd D:\筑工杯数据获取\V4_FINAL_DELIVERY\site
# Windows 若没有 python3，可临时把 python 加入 PATH 并设置 PYTHONUTF8=1（见 TEST_RESULTS/npm-check.log 说明）
npm run check
```

检查内容：JS 语法、原报告 89 段/13766 字符/41 子标题/19 文献/4 原图、11 区/8 指标/88 值、数据来源字段、无边界/地图资源、非地理面板契约。

### 测试复跑

```powershell
cd D:\筑工杯数据获取\V4_FINAL_DELIVERY
# 先启动 site 服务（默认 3000 或 3020；测试默认 3020）
node TEST_RESULTS/e2e_panel.cjs http://127.0.0.1:3020
node TEST_RESULTS/e2e_failure_missing.cjs http://127.0.0.1:3020
```

> 端口 3020 是本次审计服务；自行启动时可用 3000 并替换 URL。

---

## 4. 本轮实际测试结果（摘要）

| 测试 | 结果 |
|---|---|
| 项目自带 `npm run check` | 六项 PASS，退出码 0（日志：`TEST_RESULTS/npm-check.log`；Windows 需 Python3/UTF-8 适配） |
| 安全面板真实浏览器 E2E | **20/20 通过、0 失败**；桌面 1440×900、移动 390×844；真实鼠标/触摸/键盘；控制台 0 error、资源失败 0、外部请求 0 |
| 失败隔离/缺失值 | **5/5 通过**：阻断数据资源→降级提示、正文可读；恢复后 11 卡恢复；注入合成夹具时缺失区显示“缺失”而非 0；恢复真实数据无缺失 |
| 数据/内容 | 11 区×8 指标=88 值；89 段/13766 字符；5 章/41 子标题/19 文献/4 原图；原 V3 床位图保留 |
| 边界资源 | 部署目录**无 GeoJSON、无地图组件、无 DataV/高德边界**；测试无 `assets/maps`/GeoJSON 请求 |

**历史结果，不作为本轮新测试**：V4 原地图版 28/28 宿主 E2E、模块 48/48 均为前序执行方结果；本安全候选已按新功能重跑 20 项，而不是沿用地图版数字。

---

## 5. 数据来源与限制（必须保留）

- 指标数据来自原研究既有数据：2025 年末户籍 60+/65+/80+ 人口、2026-09 养老机构备案床位、2025-02 长者饭堂、2023-11 基层医疗机构；口径与来源详见 `site/dist/assets/data/district_metrics.json` 与 `DATA_SOURCES_AND_COMPLIANCE.md`。
- 备案床位 ≠ 实际可用床位；设施点位 ≠ 服务能力/可达性；跨年分子分母、2 条机构区划冲突、2 组饭堂同址重复、基层医疗时点较旧等限制在页面与详情中保留。
- 本候选**不使用行政区边界**，因此不再分发 DataV/高德边界数据；原 V4 地图的边界许可/坐标系/审图问题不属于本候选展示内容，但若未来恢复地图，仍需另行完成许可与审图。
- 不新增“重点关注区”、排名或因果结论；面板按行政区固定顺序，条形保留 v2 区序，均不代表推广优先级。

---

## 6. 版本与线上状态（务必区分）

| 状态 | 值 |
|---|---|
| 本地安全候选 | **已生成并测试通过**（本目录） |
| 原 Sites 项目保存版本 | V4 原地图版为 `saved_only_not_deployed`（来自原交付记录；**未经本环境服务器端核实**） |
| 本次安全候选保存到 Sites | **未保存**（本环境无 Sites 发布工具/授权） |
| 线上正式站点 | **V3**（依据现有记录；本环境未登录，无法独立复核） |
| 发布/回滚 | **均未执行** |

> 不要把本目录当作已发布线上版本。正式发布必须由具备 Sites 所有者权限的环境执行，并另行验收。

---

## 7. 明早 5 步验收

1. 解压 ZIP，进入 `site/`，运行 `npm run dev`，打开 `http://localhost:3000/#s-4-1`。
2. 在“空间分布”4.1 看 11 区卡片：切换 8 个指标；点区卡片 → 详情/条形同步；点条形 → 卡片/详情同步；重置。
3. 用键盘 Tab/Enter/Esc 操作卡片；缩到 390px 宽确认无横向溢出。
4. 查看页面数据质量/边界说明：确认“非地理示意、不使用行政区边界、不新增排名/重点区”；第2章原区位图、原V3床位图仍在。
5. 查看 `FINAL_ACCEPTANCE_REPORT.md` 与 `HANDOFF.md`：本地候选已通过；线上仍 V3，发布需授权与 Sites 工具。

---

## 8. 未闭合的外部事项（不影响本地候选运行）

1. **线上发布授权**与 **Sites 所有者会话/原生工具**；本环境无法发布/回滚。
2. Sites 版本历史中 V3/V4 的服务器端状态与回滚入口；本环境未能核实。
3. 如未来恢复原行政区地图：需取得边界数据许可/再分发授权、完成坐标系核验与地图审核/审图号；本候选未使用边界，故不涉及该展示路径。
4. Safari/Firefox、真机触摸、真实屏幕阅读器等未测。
5. `npm run check` 在部分 Windows 环境需要 Python3 与 UTF-8 适配（检查脚本问题，不影响静态站点）。
6. 原始 DOCX 未随包提供，原文仅按 `content.json`/DOM/交付记录核验。

详见 `KNOWN_LIMITATIONS.md`、`DATA_SOURCES_AND_COMPLIANCE.md`、`HANDOFF.md`。
