# V4 安全候选最终验收报告

**版本**：V4-SAFE（非地理 11 区区级比较面板）
**验收时间**：2026-10-29（Asia/Shanghai）
**被测项目**：`D:\筑工杯数据获取\V4_FINAL_DELIVERY\site`
**线上状态**：未发布；原线上仍为 V3（依据现有记录；本环境未登录，无法独立复核）。

> 本报告只记录**本轮实际运行**的测试；前序 V4 地图版的 28/28、模块 48/48 另行标注为历史结果，不冒充本轮新测试。

---

## 1. 本轮新运行的测试

### 1.1 项目自带检查（实际执行）

命令（在 `site/`，需 Python3/UTF-8 环境；Windows 适配见 `TEST_RESULTS/npm-check.log`）：

```
npm run check
```

结果：**退出码 0，六项 PASS**：

1. 5 章、41 子标题、7 场景分类、19 文献、4 原图、原文范围与关键边界；
2. 11 区排序、中位数、9 项年度原值/变化率、3 组相关统计；
3. 面板 provider 早于 mount、清理、异步失败降级、卸载后注册；
4. 19 项原稿引文映射、背景事实、视图入口；
5. 安全面板契约：无边界几何/地图资源；11区8指标88值；来源/单位/年份/质量字段完整；无地图引用；89段/13766字符/19文献。

日志：`TEST_RESULTS/npm-check.log`。

### 1.2 真实浏览器 E2E（本轮新运行）

- 工具：真实 Microsoft Edge 156 headless + CDP；真实鼠标/触摸/滚轮/键盘输入。
- 桌面 **1440×900**；移动 **390×844（mobile:true, dpr2，真实布局视口）**。
- 结果：**20/20 通过、0 失败**；控制台 script error **0**；资源失败 **0**；外部请求 **0**。
- 用例（摘要）：
  - 11 区卡片、11 条形、8 指标按钮；无 `gz-district-map`/GeoJSON/`assets/maps` 请求；
  - 8 指标真实点击：每个指标 11 个卡片值/条形值与 `district_metrics.json` 一致（**88/88**）；标题/单位/年份/图例/来源同步；
  - 卡片点击→详情/条形同步；条形点击→卡片/详情同步；
  - 重置清空选中并恢复默认指标；
  - 键盘 Enter 选中、Esc 清除（卡片显式处理 Enter/Space，原生按钮能力）；
  - 第4章→第2章→后退恢复滚动位置、面板实例仍为 1、前进回第2章；
  - 移动端 390px 无横向溢出；触摸卡片选中；无控制台错误/外部请求；
  - 无边界/地图资源请求，证明安全替代实际生效。
- 机读：`TEST_RESULTS/e2e-results.json`。
- 截图：`TEST_RESULTS/screenshots/desktop-panel-default.png`、`desktop-panel-selected.png`、`mobile-panel.png`。

### 1.3 失败隔离与缺失值（本轮新运行）

- 结果：**5/5 通过、0 失败**。
- 阻断数据资源 `assets/data/*` → 显示降级提示，报告正文/原图表仍可读；解除阻断并 reload 后恢复 11 卡。
- 注入合成缺失夹具（海珠/从化 bedDensity 为 null）：海珠/从化卡片显示“缺失”，详情不显示 0；图例/夹具提示正确；移除夹具并加载真实数据后无缺失。
- 机读：`TEST_RESULTS/e2e-failure-missing.json`。

### 1.4 静态/数据具体核验（本轮）

- 部署目录 `site/dist` **无 `.geojson`、无 `assets/maps/`、无 `map-provider.js`、无 `gz-district-map.js`**；扫描所有 JS 无 `gz_districts_11`/`assets/maps` 引用。
- `district_metrics.json`：11 区、8 指标、88 个区×指标值；adcode 11/11 唯一；无 `_fixture`；`focus.status=not_configured`；每个指标包含 label/unit/years/numerator/denominator/source/qualityNote。
- `content.json`：89 段、13,766 字符、5章、41子标题、19文献、4原图；原 V3 床位图在 DOM 中保留 11 行。
- 面板数据来源/单位/年份/质量字段在页面图例/详情中可见。
- 无敏感凭据；部署运行无外部请求（E2E）。

---

## 2. 与历史结果的区别

| 测试 | 来源 | 是否本轮新跑 |
|---|---|---|
| V4 原地图版 28/28 宿主 E2E | 前序独立验收（2026-10-29 00:27–00:42） | **否**（历史） |
| 地图模块 48/48 单测 | 交付模块原执行方 | **否**（历史） |
| V4 原地图版 `npm run check` | 前序独立验收 | **否**（历史；本候选重新运行了自己的 check） |
| 本安全候选 `npm run check` | 本轮 | **是** |
| 本安全候选 20/20 E2E | 本轮 | **是** |
| 本安全候选 5/5 失败/缺失测试 | 本轮 | **是** |

> 安全候选不是原 V4 地图版；原有“地图版 28/28/48/48”不能直接作为本候选的验收数字，故已按新功能重跑。

---

## 3. 本轮实际修改（相对 V4）

1. 移除部署目录中的 `dist/assets/maps/`（行政区边界 GeoJSON + 地图组件 JS）、`dist/map-provider.js/css`。
2. 新增 `dist/district-panel-provider.js`、`dist/district-panel.css`：非地理 11 区比较面板；11 卡、8 指标、详情、联动条形、重置、键盘、移动端、缺失值。
3. 指标数据移动到 `dist/assets/data/district_metrics.json`（未改数值；无边界 geometry）。
4. 更新 `index.html`、`overview.js` 的 4.1 文案与质量控制提示：明确“不使用行政区边界、不叠加底图、不提供地理定位/量测”；保留第2章原区位图与第4章原 V3 床位图。
5. 更新 `map-slot.js` fallback 文案；更新 `qa-map-host.html` 文案。
6. 更新 `package.json`（0.4.0）与检查脚本：新增 `verify_district_panel.py`、`verify_panel_slot.mjs`，移除地图资源检查。
7. 更新 `site/README.md`；新增 `CANDIDATE_STATE.json`，移除原 `DELIVERY_STATE.json`（避免把候选误认为已保存版本）。
8. 未修改：`dist/content.json`、`dist/visual-data.json`、4张原图、章节路由、研究结论/参考文献。

每个文件的实际变更见 `CHANGELOG.md`。

---

## 4. 仍需外部条件的事项

1. **正式站点发布/回滚**：本环境无 Sites 原生工具、无合法登录会话；未发布、未回滚。线上仍 V3（按现有记录）。
2. **Sites 服务器端版本状态**：V3/V4 的版本历史/恢复入口未由本环境核实；不能以 `CANDIDATE_STATE` 或历史 `DELIVERY_STATE` 证明。
3. **若未来恢复行政区地图**：必须另行取得边界许可/再分发授权、完成坐标系核验与地图审核/审图号；本候选未使用边界，故本候选不展示该风险内容。
4. **浏览器/设备**：Safari/Firefox、真机触摸、真实屏幕阅读器未测。
5. **Windows 检查环境**：`npm run check` 需要 Python3/UTF-8；原项目未内置 Windows 兼容。
6. **原始 DOCX**：未随包提供；原文按 `content.json`/DOM/交付记录核验。

---

## 5. 结论

**本安全候选在本地通过可执行静态检查与真实浏览器测试，可以交付验收。** 它不依赖未闭合的行政区边界许可/审图，保留了报告结构、原文、数据口径、区级比较与联动交互。  
**它不是正式线上版本；线上仍为 V3；发布/回滚仍需授权环境。**
