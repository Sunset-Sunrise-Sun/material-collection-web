# V5.1 TEST_RESULTS

**实际执行**：2026-10-29；Edge 156/CDP；桌面 1440×900、移动 390×844。

| 文件 | 内容 |
|---|---|
| `v51-e2e-results-local.json` | 本地 E2E：21/21 通过 |
| `v51-e2e-results-offline.json` | 外部 HTTPS 阻断 E2E：21/21 通过 |
| `v51-e2e-results-package-offline.json` | 解压 V5.1 ZIP 后离线 E2E：21/21 通过 |
| `v51-e2e-local.log` / `v51-e2e-offline.log` / `v51-package-offline.log` | 对应运行日志 |
| `v51-failure-results.json` / `v51-failure.log` | 地图资源失败降级 + 合成缺失值 |
| `npm-check-v51.log` | `npm run check`：PASS，退出码 0 |
| `screenshots/before-v51-layout.png` | 修改前 V5 地图+长侧栏布局 |
| `screenshots/v51-layout-default.png` / `v51-layout-selected.png` | V5.1 地图+精简概览+下方详情 |
| `screenshots/v51-detail-desktop.png` / `v51-detail-mobile.png` | 完整详情全宽/移动端 |
| `screenshots/v51-chart-scatter.png` | 探索性散点图默认可见 |
| `screenshots/before-chart-scatter-v5.png` | 修改前散点图折叠状态 |
| `screenshots/v51-charts-chapter4.png` | 第4章图表默认可见 |
| `screenshots/v51-mobile-map.png` | 390px 地图 |
| `screenshots/v51-map-fallback.png` | 地图资源失败降级 |

## 摘要

- 布局：地图/概览顶部对齐、等高；完整详情全宽在下；无横向溢出。
- 地图：11 区/8 指标/88 值/地图↔条形/详情/重置/缩放/滚轮/拖拽/键盘。
- 图表：散点图无需点击；第 2/4 章图表默认可见；ρ/p/n 与解释保留。
- 内容/数据：89段/13,766字/41子标题/19文献/4图；数据文件 SHA-256 与 V5 相同。
- 控制台 0 error；外部请求 0；正常资源失败 0（受控失败除外）。

## 历史结果

V5 的 14/14、V4 28/28、模块 48/48 为前序结果，不作为 V5.1 本轮数字。
