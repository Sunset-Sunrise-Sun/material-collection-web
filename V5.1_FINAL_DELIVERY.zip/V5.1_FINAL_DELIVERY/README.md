# V5.1 排版优化候选 — 地图/详情布局 + 全站图表默认展示

**分支**：`feat/v5-layout-polish`
**基线**：`feat/map-integration-v5` @ `fc35704d4c1839f3d83dc115c7fdb599ce4fe1f5`
**状态**：**本地/分支候选；未合并 main、未部署、未覆盖当前 GitHub Pages。**

## 快速运行

解压 `V5.1_FINAL_DELIVERY.zip`，双击：

```text
start-local.bat
```

打开 `http://127.0.0.1:8765/#s-4-1`。需要 Node.js 18+（或 Python 3 兜底）。
源码运行：`cd site && npm run dev`。

## 本轮改了什么

1. **4.1 地图布局**：地图与精简区级概览并排；完整详情全宽位于下方。
   - 地图仍由原 `gz-district-map` 渲染；11 区/8 指标/2.5D/缩放/平移/联动全部保留。
   - 精简概览显示选中区、当前指标、少量关键指标、范围/中位数、来源摘要和简短数据质量提示。
   - 完整详情仍由**同一地图组件的面板**投影生成，包含全部 8 项指标、原始计数、来源、年份/分母、质量提示；不复制独立状态。
   - 地图容器高度调为合理范围，左右卡片等高，减少无意义空白。
2. **全站图表默认展示**：
   - 第 2 章探索性散点图（image1）的折叠默认展开；
   - 床位密度图、相关统计/解释默认展开；
   - 4.1.1/4.1.2 的报告图从“完整原文”折叠中移出，直接显示；
   - 年度图、image2/3/4 原本直接显示；
   - 长篇完整原文仍可折叠；原有标题、解释、统计口径、Spearman/p/n、图例、来源未改写。
3. **离线包同步**：V5.1 独立 ZIP，保留原 V5 ZIP 不覆盖。

## 本轮测试（实际）

- 本地 E2E：**21/21 通过**；
- 外部 HTTPS 阻断 E2E：**21/21 通过**；
- 解压 ZIP 后离线运行：**21/21 通过**；`start-local.bat` 实启 HTTP 200；
- 数据文件与正文：`content.json`、`visual-data.json`、指标 JSON、GeoJSON、4 原图哈希与 V5 完全一致；
- 图表：探索性散点图无需点击即可见，Spearman/p/n 文字保留；所有图表默认可见；
- 390px：无横向溢出，地图/概览/完整详情纵向排列。

详细证据：[`TEST_REPORT_V5.1.md`](TEST_REPORT_V5.1.md)、[`TEST_RESULTS`](TEST_RESULTS)。

## 目录

```
V5.1_FINAL_DELIVERY/
├─ start-local.bat
├─ site/                        完整源码（含 V5.1 布局/图表修改）
├─ BOUNDARY_LICENSE_AND_REVIEW.md
├─ TEST_REPORT_V5.1.md
├─ CHANGELOG_V5.1.md
├─ HANDOFF_V5.1.md
├─ OFFLINE_PACKAGE.md
└─ TEST_RESULTS/                实际测试、截图、日志
```

## 边界/审核状态（不变）

边界层仍为 **OpenStreetMap/ODbL 1.0**（不是原 DataV）；**地图审核/审图号未取得**，OSM 边界非官方勘定界线，坐标按 OSM 的 WGS84 记录，未与官方标准画法图独立核验。本候选仅供内部评审/离线验收，公开或正式提交前需完成地图审核判断。

## 数据/研究边界（不变）

备案床位 2026-09 ≠ 实际可用床位；2025 户籍 60+ 跨年分母；设施数量 ≠ 服务能力；2 条机构区划冲突、2 组饭堂同址、基层医疗 2023-11；`focusRule=null`，不标重点区、不新增排名/因果。
