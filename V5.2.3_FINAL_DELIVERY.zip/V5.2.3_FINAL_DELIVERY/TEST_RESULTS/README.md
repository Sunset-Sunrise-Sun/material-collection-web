# V5.2 TEST_RESULTS

**实际运行**：2026-10-29；Edge 156 + CDP；1440×900、390×844；外部 HTTPS 阻断。

| 文件 | 内容 |
|---|---|
| `v52-e2e.log` / `v52-e2e-results.json` | V5.2 E2E：28/28 通过（布局、排序、键盘、图表、移动端） |
| `v52-failure.log` / `v52-failure-results.json` | 地图资源失败/恢复 + 合成缺失值：通过 |
| `npm-check-v52.log` / `npm-check-v52-extracted.log` | 开发目录/解压包 `npm run check`：5项 PASS |
| `screenshots/v52-desktop-map.png` | 4.1 地图+条形+双卡三列 |
| `screenshots/v52-research-area.png` | 研究区域仅一张定位图 |
| `screenshots/v52-image4-results.png` | 最新版image4在4.1.2默认可见 |
| `screenshots/v52-charts-chapter4.png` | 第4章图表默认显示 |
| `screenshots/v52-mobile-map.png` | 390px 地图/条形/卡片纵向 |
| `screenshots/before-*.png` | V5.1.1修改前对照 |

脚本保留 `v52_e2e.cjs`、`v51_failure.cjs` 供复核。解压包 E2E：`v52-package-e2e.log`（28/28）。
